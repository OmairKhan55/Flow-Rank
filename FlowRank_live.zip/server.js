const express=require("express");
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;
const API_KEY=process.env.CG_API_KEY;
app.use(express.static(path.join(__dirname,"public")));
app.get("/api/crypto",async(req,res)=>{
  try{
    if(!API_KEY)return res.status(500).json({error:"CG_API_KEY missing"});
    const url="https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=volume_desc&per_page=100&page=1&sparkline=false";
    const r=await fetch(url,{headers:{"x-cg-demo-api-key":API_KEY}});
    res.status(r.status).json(await r.json());
  }catch(e){res.status(500).json({error:"Could not load market data"});}
});
app.listen(PORT,()=>console.log("FlowRank running on port "+PORT));
